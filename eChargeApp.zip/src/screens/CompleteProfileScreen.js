import { StyleSheet, Text, View } from "react-native";
import React from "react";

const CompleteProfileScreen = () => {
  return (
    <View>
      <Text style={styles.text}>CompleteProfileScreen</Text>
    </View>
  );
};

export default CompleteProfileScreen;

const styles = StyleSheet.create({
  text: {
    fontSize: 14,
  },
});
