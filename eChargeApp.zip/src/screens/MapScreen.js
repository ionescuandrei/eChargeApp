import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import React from "react";
import { signOut } from "firebase/auth";
import auth from "../firebase-config";
import { useNavigation } from "@react-navigation/native";
const MapScreen = () => {
  const navigation = useNavigation();
  const exitApp = () => {
    signOut(auth)
      .then(() => navigation.navigate("TabNav"))
      .catch((error) => console.error(error));
  };
  return (
    <View>
      <TouchableOpacity onPress={exitApp}>
        <Text>signOut</Text>
      </TouchableOpacity>
      <Text>MapScreen</Text>
    </View>
  );
};
const styles = StyleSheet.create({});
export default MapScreen;
