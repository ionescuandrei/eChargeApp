import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const TrackListScreen = () => {
  return (
    <View>
      <Text>TrackListScreen</Text>
    </View>
  )
}

export default TrackListScreen

const styles = StyleSheet.create({})